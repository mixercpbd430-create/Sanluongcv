@echo off
REM ============================================
REM  Xem lịch sử upload (10 lần gần nhất)
REM ============================================

echo.
echo ========================================
echo   LICH SU UPLOAD (10 lan gan nhat)
echo ========================================
echo.

set SCRIPT_DIR=%~dp0
set HISTORY_FILE=%SCRIPT_DIR%upload_history.json

if not exist "%HISTORY_FILE%" (
    echo Chua co lich su upload nao.
    echo Chay auto_upload.py hoac test_upload.bat truoc.
    pause
    exit /b 0
)

python -c "import json,os;f=open(r'%HISTORY_FILE%','r',encoding='utf-8');h=json.load(f);f.close();entries=h[-10:];print();[print(f'  [{e[\"timestamp\"]}] {chr(9989) if e[\"status\"]==\"success\" else chr(10060) if e[\"status\"]==\"error\" else chr(128308) if e[\"status\"]==\"dry-run\" else chr(9888)} {e[\"status\"].upper():10s} | User: {e.get(\"username\",\"?\"):15s} | Gui: {e.get(\"records_sent\",0):>4d} | Luu: {e.get(\"records_saved\",0):>4d} | Bo qua: {e.get(\"records_skipped\",0):>4d}' + (f' | Loi: {e[\"errors\"]}' if e.get('errors') else '')) for e in entries];print(f'\n  Tong: {len(h)} lan upload trong lich su')"

echo.
echo ========================================
echo   File log:    %SCRIPT_DIR%upload.log
echo   File JSON:   %HISTORY_FILE%
echo ========================================
echo.

pause
